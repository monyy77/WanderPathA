from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional

from state_graph.refundGraph.hitl import apply_human_decision
from state_graph.refundGraph.refund_graph import resume_run
from state_graph.checkpointer import load_checkpoint, load_history
from shared.database import get_connection

router = APIRouter(prefix="/admin/refunds", tags=["Admin Refund Management"])

class HITLDecisionRequest(BaseModel):
    run_id: str
    approved: bool
    approver_id: int
    reason: Optional[str] = ""


@router.post("/hitl-decision")
async def handle_hitl_decision(payload: HITLDecisionRequest, background_tasks: BackgroundTasks):
    try:
        state = apply_human_decision(
            run_id=payload.run_id,
            approved=payload.approved,
            approver_id=payload.approver_id,
            reason=payload.reason
        )
  
        background_tasks.add_task(resume_run, payload.run_id)
        return {"status": "success", "message": "Decision applied & graph resumed", "state": state}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/tickets")
def get_failure_tickets():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT escalation_id, booking_id, employee_id, reason, status, created_date 
        FROM Escalations 
        ORDER BY created_date DESC
    """)
    tickets = cursor.fetchall()
    cursor.close()
    conn.close()
    return {"tickets": tickets}


@router.get("/checkpoints/{run_id}")
def get_run_history(run_id: str):
    history = load_history(run_id)
    latest = load_checkpoint(run_id)
    if not latest:
        raise HTTPException(status_code=404, detail="Run ID not found")
    return {"latest_status": latest["status"], "history": history}